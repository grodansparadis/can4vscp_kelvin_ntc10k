/*
 * NTC thermistor library
 * Version 1.0
 * Copyright (C) 2007, 2013 - SoftQuadrat GmbH, Germany
 * Contact: thermistor (at) softquadrat.de
 * Web site: thermistor.sourceforge.net
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 */
package de.softquadrat.ntc;

import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Represents a T-R table (temperature versus resistance) for an NTC thermistor.
 */
public class NtcTable {
	/** Name of this table's NTC thermistor. */
	private String name;
	/** Full description of this table's NTC thermistor. */
	private String description;
	/** Temperatur to resistance map. */
	private SortedMap<Double, Double> map;

	/**
	 * Creates a new instance with name and given description.
	 * @param name NTC thermistor name.
	 * @param description this table's NTC thermistor description.
	 */
	public NtcTable(String name, String description) {
		this.name = name;
		this.description = description;
		map = new TreeMap<Double, Double>();
	}

	/**
	 * Adds a new temperature resistance pair to this table.
	 * @param tempString the temperature value.
	 * @param resString the corresponding resistance value.
	 */
	public void add(String tempString, String resString) {
		double temperature = Double.parseDouble(tempString);
		double resistance = Double.parseDouble(resString);
		map.put(temperature, resistance);
	}

	/**
	 * Gets the number of temperature value in this table.
	 * @return the number of temperature value in this table.
	 */
	public int getNumberOfTemperatures() {
		return map.size();
	}

	/**
	 * Gets a Set with all temperatures in this table.
	 * @return a Set with all temperatures in this table.
	 */
	public Set<Double> getTemperatures() {
		return map.keySet();
	}

	/**
	 * Gets the resistance for a given temperature value.
	 * @param temperature the temperature value.
	 * @return the resistance value.
	 * @throws NtcException in case no temperature-resistance pairs can be found.
	 */
	public double getResistance(double temperature) throws NtcException {
		if (!map.containsKey(temperature))
			throw new NtcException("Temperature value " + temperature + " not found in Ntc table: " + name);
		return map.get(temperature);
	}

	/**
	 * Gets the name of this table's NTC thermistor.
	 * @return the name of this table's NTC thermistor.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the description of this table's NTC thermistor.
	 * @return the description of this table's NTC thermistor.
	 */
	public String getDescription() {
		return description;
	}

}
