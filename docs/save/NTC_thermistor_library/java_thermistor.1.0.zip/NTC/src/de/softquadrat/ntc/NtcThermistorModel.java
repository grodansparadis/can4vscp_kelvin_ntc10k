/*
 * NTC thermistor library
 * Version 1.0
 * Copyright (C) 2007, 2013 - SoftQuadrat GmbH, Germany
 * Contact: thermistor (at) softquadrat.de
 * Web site: thermistor.sourceforge.net
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 */
package de.softquadrat.ntc;

/**
 * Represents an NTC thermistor modelled using a Steinhart-Hart polynom
 * <p><code>
 * p(x) = a<sub>3</sub> &middot; x<sup>3</sup>
 * + a<sub>1</sub> &middot; x
 * + a<sub>0</sub>
 * .</code></p>
 * The thermistor will be created using a T-R table (temperature versus resistance).
 * From this a Steinhart-Hart polynom is calculated that will best fit
 * the values in the T-R table.
 *
 * Public method to convert temperature into resistance values based on the Steinhart-Hart
 * polynom and vice versa are offered.
 */
public class NtcThermistorModel {
	/** The absolute zero point in Celsius. */
	static protected final double TABS = -273.15;
	/** The NTC table used. */
	private final NtcTable table;
	/** x values derived from our NTC table. */
	private double[] x;
	/** y values derived from our NTC table. */
	private double[] y;
	/** The approximating Steinhart-Hart polynom. */
	private double[] steinhartHartPolynom;

	/**
	 * Constructs a new instance based on an NTC table.
	 * @param table NTC table with T-R pairs.
	 * @throws NtcException in case of missing temperature found.
	 */
	public NtcThermistorModel(NtcTable table) throws NtcException {
		this.table = table;
		int dimension = table.getNumberOfTemperatures();
		x = new double[dimension];
		y = new double[dimension];
		int i = 0;
		for (double temperature : table.getTemperatures()) {
			x[i] = Math.log(table.getResistance(temperature));
			y[i] = 1.0 / (temperature - TABS);
			i++;
		}
		double [][] base = getBase();
		orthonormal(base);
		steinhartHartPolynom = approx(base);
	}

	/**
	 * Calculates temperature for a given resistance value.
	 * @param resistance resistanc of NTC.
	 * @return calculated temperature value (in Celsius).
	 */
	public double calcTemperature(double resistance) {
		double ti;

		ti = value(steinhartHartPolynom, Math.log(resistance));
		ti = 1.0 / ti + TABS;
		return ti;
	}

	/**
	 * Calculates resistance for a given temperature value.
	 * @param temperature temperature (in Celsius).
	 * @return calculated resistance value.
	 */
	public double calcResistance(double temperature) {
		double r;
		double u, v, p, q, b, c, d;

		temperature = temperature - TABS;
//System.out.println("temperature = " + temperature);
		d = (steinhartHartPolynom[0] - 1.0 / temperature) / steinhartHartPolynom[3];
//System.out.println("d = " + d);
		c = steinhartHartPolynom[1] / steinhartHartPolynom[3];
//System.out.println("c = " + c);
		b = steinhartHartPolynom[2] / steinhartHartPolynom[3];
//System.out.println("b = " + b);
		q = 2.0 / 27.0 * b * b * b - 1.0 / 3.0 * b * c + d;
//System.out.println("q = " +  q);
		p = c - 1.0 / 3.0 * b * b;
//System.out.println("p = " + p);
		v = -Math.pow(q / 2.0 + Math.sqrt(q * q / 4.0 + p * p * p / 27.0),
			1.0 / 3.0);
//System.out.println("v = " + v);
		u = Math.pow(-q / 2.0 + Math.sqrt(q * q / 4.0 + p * p * p / 27.0),
			1.0 / 3.0);
//System.out.println("u = " + u);
		r = Math.exp(u + v - b / 3.0);
//System.out.println("r = " + r);
		return r;
	}

	/**
	 * Gets the name of the thermistor.
	 * @return the name of the thermistor.
	 */
	public String getName() {
		return table.getName();
	}

	/**
	 * Gets the full name of the NTC thermistor.
	 * @return the full name of the NTC thermistor.
	 */
	public String getDescription() {
		return table.getDescription();
	}

	/**
	 * Gets the underlying R-T table.
	 * @return the underlying R-T table.
	 */
	public NtcTable getTable() {
		return table;
	}

	/**
	 * Gets the Steinhart-Hart polynom of this thermistor.
	 * @return the Steinhart-Hart polynom of this thermistor.
	 */
	public double[] getSteinhartHartPolynom() {
		return steinhartHartPolynom;
	}

	/**
	 * Gets a base for subspace U.
	 * @return base for subspace U.
	 */
	double [][] getBase() {
		double [][] base = new double [][] {
			{ 1.0, 0.0, 0.0, 0.0 },
			{ 0.0, 1.0, 0.0, 0.0 },
			{ 0.0, 0.0, 0.0, 1.0 },
		};
		return base;
	}

	/**
	 * Evaluates value of <code>p(x)</code> for a given polynom <code>p</code> from space U at <code>x</code>.
	 * Calculation is done using Horners scheme.
	 * @param p polynom of degree <code>subDimension</code> (given as array of doubles).
	 * @param x value inserted into the polynom.
	 * @return calculated value of <code>p(x)</code>.
	 */
	double value(double[] p, double x) {
		int i;
		double retval = 0.0;
		for (i = p.length - 1; i >= 0; i--)
			retval = retval * x + p[i];
		return retval;
	}

	/**
	 * Calculate scalar product <code>[p, q]<code> of polynoms <code>p</code> and <code>q</code> in space V.
	 * The scalar product is defined as
	 * <blockquote>
	 * <table border="0" cellpadding="0" cellspacing="0">
	 * <tr>
	 * <td>&nbsp;</td>
	 * <td><sub>&nbsp;dimension</sub></td>
	 * </tr>
	 * <tr>
	 * <td>[p, q] :=</td>
	 * <td><font size="+3">&Sigma;</font> p(x<sub>i</sub>) &middot; q(x<sub>i</sub>)</td>
	 * </tr>
	 * <tr>
	 * <td>&nbsp;</td>
	 * <td><sup>i=0</sup></td>
	 * </tr>
	 * </table>
	 * </blockquote>
	 * @param p first polynom (given as array of doubles).
	 * @param q second polynom (given as array of doubles).
	 * @return calculated scalar product.
	 */
	double skalarpoly(double[] p, double[] q) {
		int i;
		double retval = 0.0;
		for (i = 0; i < x.length; i++)
			retval += value(p, x[i]) * value(q, x[i]);
		return retval;
	}

	/**
	 * Evaluates <code>p *= fact</code>.
	 * Multiplies a polynom <code>p</code> from space U with a factor <code>fact</code>.
	 * @param p polynom (given as array of doubles).
	 * @param fact factor used to multiply with.
	 */
	void mult(double[] p, double fact) {
		int i;
		for (i = 0; i < p.length; i++)
			p[i] *= fact;
	}

	/**
	 * Evaluates <code>p += fact&middot;q</code>.
	 * Adds a polynom <code>q</code> multiplied with a factor <code>fact</code> to a given polynom <code>p</code>
	 * (both polynoms from U).
	 * @param p first polynom (given as array of doubles).
	 * @param q second polynom (given as array of doubles).
	 * @param fact factor used to multiply second polynom with.
	 */
	void linear(double[] p, double[] q, double fact) {
		int i;
		for (i = 0; i < p.length; i++)
			p[i] += q[i] * fact;
	}

	/**
	 * Ortho-normalizes a given base of U.
	 * @param base base to be ortho-normalized (given as array of doubles).
	 */
	void orthonormal(double[][] base) {
		int i, j;
		double fact, norm;
		for (i = 0; i < base.length; i++) {
			for (j = 0; j < i; j++) {
				fact = skalarpoly(base[i], base[j]);
				linear(base[i], base[j], -fact);
			}
			norm = skalarpoly(base[i], base[i]);
			mult(base[i], 1.0 / Math.sqrt(norm));
		}
	}

	/**
	 * Evaluates scalar product <code>[p, p<sub>f</sub>]</code> for a given
	 * polynom <code>p</code> from U with the solving polynom <code>p<sub>f</sub></code> in V.
	 * @param p polynom used to multipy with (given as array of doubles).
	 * @return calculated scalar product.
	 */
	double skalar(double[] p) {
		int i;
		double retval = 0.0;
		for (i = 0; i < x.length; i++)
			retval += y[i] * value(p, x[i]);
		return retval;
	}

	/**
	 * Evaluate approximation polynom <code>u<sub>f</sub></code> in U.
	 * The evaluation is done using the formula
	 * <blockquote>
	 * <table border="0" cellpadding="0" cellspacing="0">
	 * <tr>
	 * <td>&nbsp;</td>
	 * <td><sub>&nbsp;m-1</sub></td>
	 * </tr>
	 * <tr>
	 * <td>u<sub>f</sub> =</td>
	 * <td><font size="+3">&Sigma;</font> [ u<sub>i</sub>, p<sub>f</sub> ] &middot; u<sub>i</sub></td>
	 * </tr>
	 * <tr>
	 * <td>&nbsp;</td>
	 * <td><sup>i=0</sup></td>
	 * </tr>
	 * </table>
	 * </blockquote>
	 */
	double[] approx(double[][] orthoBasis) {
		int i;
		double fact;
		double [] solution = new double[orthoBasis[0].length];
		for (i = 0; i < orthoBasis.length; i++) {
			fact = skalar(orthoBasis[i]);
			linear(solution, orthoBasis[i], fact);
		}
		return solution;
	}

}
