/*
 * NTC thermistor library
 * Version 1.0
 * Copyright (C) 2007, 2013 - SoftQuadrat GmbH, Germany
 * Contact: thermistor (at) softquadrat.de
 * Web site: thermistor.sourceforge.net
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 */
package de.softquadrat.ntc;

/**
 * Exception used in this thermistor framework.
 */
public class NtcException extends Exception {
	private static final long serialVersionUID = -8363161732244962846L;

	/**
	 * Constructs a new instance.
	 */
	public NtcException() {
		super();
	}

	/**
	 * Constructs a new instance with given message.
	 * @param msg message to use.
	 */
	public NtcException(String msg) {
		super(msg);
	}

	/**
	 * Constructs a new instance with given message and cause.
	 * @param msg message to use.
	 * @param cause cause to use.
	 */
	public NtcException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * Constructs a new instance with given cause.
	 * @param cause cause to use.
	 */
	public NtcException(Throwable cause) {
		super(cause);
	}
}
