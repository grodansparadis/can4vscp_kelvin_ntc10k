/*
 * NTC thermistor library
 * Version 1.0
 * Copyright (C) 2007, 2013 - SoftQuadrat GmbH, Germany
 * Contact: thermistor (at) softquadrat.de
 * Web site: thermistor.sourceforge.net
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 */
package de.softquadrat.ntc.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Set;
import java.util.StringTokenizer;

import de.softquadrat.ntc.NtcException;
import de.softquadrat.ntc.NtcTable;
import de.softquadrat.ntc.NtcThermistorExtendedModel;
import de.softquadrat.ntc.NtcThermistorModel;
import de.softquadrat.ntc.NtcThermistorSimplifiedModel;

/**
 * Test class demonstrating the calculation of Steinhart-Hart coefficients
 * for a theoretical NTC.
 */
public class NtcTest {
	public static void main(String[] args) throws NtcException {
		System.out.println("Thermistor library version 1.0");
		System.out.println("Copyright (C) 2007, 2013 - SoftQuadrat GmbH, Germany");
		System.out.println();
		InputStream is = NtcTest.class.getResourceAsStream("simu.txt");
		BufferedReader br;
		String line;
		NtcTable table = new NtcTable("Simu", "Simulated NTC");
		br = new BufferedReader(new InputStreamReader(is));
		try {
			while ((line = br.readLine()) != null) {
				line = line.trim();
				StringTokenizer tokenizer = new StringTokenizer(line);
				int cnt = tokenizer.countTokens();
				if (cnt != 2)
					throw new NtcException("Wrong number of tokens encountered in line:\n" + line);
				String temperature = tokenizer.nextToken();
				String resistance = tokenizer.nextToken();
				table.add(temperature, resistance);
			}
		} catch (IOException e) {
			throw new NtcException(e.getMessage(), e);
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				throw new NtcException(e.getMessage(), e);
			}
		}
		NtcThermistorModel ntc = new NtcThermistorSimplifiedModel(table);
		System.out.println("Simplified Model");
		doCalculation(table, ntc);
		ntc = new NtcThermistorModel(table);
		System.out.println("Standard Model");
		doCalculation(table, ntc);
		ntc = new NtcThermistorExtendedModel(table);
		System.out.println("Extended Model");
		doCalculation(table, ntc);
	}

	private static void doCalculation(NtcTable table, NtcThermistorModel ntc) throws NtcException {
		System.out.println("------------------------------------------------------------------------");
		double[] steinhartHartPolynom = ntc.getSteinhartHartPolynom();
		System.out.print("Steinhart-Hart polynom: ");
		for (int i = steinhartHartPolynom.length - 1; i >= 0; i--) {
			if (steinhartHartPolynom[i] == 0.0)
				continue;
			String fmt;
			if (i == 0)
				fmt = " %e";
			else if (i == 1)
				fmt = " %e * x";
			else
				fmt = " %e * x^" + i;
			if (i < steinhartHartPolynom.length - 1)
				fmt = " + " + fmt;
			System.out.printf(fmt, steinhartHartPolynom[i]);
		}
		System.out.println("\n");
		double maxErr = 0.0;
		double errTemp = 0.0;
		Set<Double> temperatures = table.getTemperatures();
		for (Double t: temperatures) {
			double r = table.getResistance(t);
			double calcT = ntc.calcTemperature(r);
			double calcR = ntc.calcResistance(t);
			double err = Math.abs(calcT - t);
			if (err > maxErr) {
				maxErr = err;
				errTemp = t;
			}
			System.out.printf("temperature=%4.0f\tresistance=%8.1f\tcalculated temperature=%9.2f\tcalculated resistance=%9.2f\n", t, r, calcT, calcR);
		}
		System.out.println();
		System.out.printf("Maximal error=%7.5f at temperature=%5.1f\n", maxErr, errTemp);
		System.out.println("========================================================================\n");
	}
}
