/*
 * NTC thermistor library
 * Version 1.0
 * Copyright (C) 2007, 2013 - SoftQuadrat GmbH, Germany
 * Contact: thermistor (at) softquadrat.de
 * Web site: thermistor.sourceforge.net
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 */
package de.softquadrat.ntc;

/**
 * Represents an NTC thermistor modelled using a simplified Steinhart-Hart polynom
 * <p><code>
 * p(x) = a<sub>1</sub> &middot; x
 * + a<sub>0</sub>
 * .</code></p>
 * In contradiction to the base class <code>NtcThermistorModel</code> this class
 * uses a polynom of degree 1. This approach is useful for application with less
 * CPU power to speed up the conversion from resistance to temperature.
 */
public class NtcThermistorSimplifiedModel extends NtcThermistorModel {
	/**
	 * Creates a new instance using the given T-R table.
	 * @param table the T-R table.
	 * @throws NtcException in case of errors
	 */
	public NtcThermistorSimplifiedModel(NtcTable table) throws NtcException {
		super(table);
	}

	/**
	 * @inheritDoc
	 */
	double [][] getBase() {
		double [][] base = new double [][] {
			{ 1.0, 0.0, 0.0, 0.0 },
			{ 0.0, 1.0, 0.0, 0.0 },
		};
		return base;
	}

	@Override
	public double calcResistance(double temperature) {
		temperature = temperature - TABS;
		double[] steinhartHartPolynom = getSteinhartHartPolynom();
		double resistance = Math.exp((1 / temperature - steinhartHartPolynom[0]) / steinhartHartPolynom[1]);
		return resistance;
	}
}
