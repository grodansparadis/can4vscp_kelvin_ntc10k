var files =
[
    [ "coeff.c", "coeff_8c.html", "coeff_8c" ],
    [ "rtot.c", "rtot_8c.html", "rtot_8c" ],
    [ "ttor.c", "ttor_8c.html", "ttor_8c" ]
];