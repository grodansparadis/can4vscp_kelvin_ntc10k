var ttor_8c =
[
    [ "TABS", "ttor_8c.html#af3d79ba52f2d41597f8f314c02c86026", null ],
    [ "main", "ttor_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "ttor", "ttor_8c.html#a3e39aa7dba09044c6a29d16959475dfa", null ],
    [ "a", "ttor_8c.html#a16fb6e591f128f46894b71401d0b2bcc", null ]
];