var coeff_8c =
[
    [ "DEBUG", "coeff_8c.html#ad72dbcf6d0153db1b8d8a58001feed83", null ],
    [ "M", "coeff_8c.html#a52037c938e3c1b126c6277da5ca689d0", null ],
    [ "MAX_LENGTH", "coeff_8c.html#a7a9a231e30b47bc0345749c8bd1e5077", null ],
    [ "TABS", "coeff_8c.html#af3d79ba52f2d41597f8f314c02c86026", null ],
    [ "polynom", "coeff_8c.html#a1a34e732cfb563b8f4e80ed59065c31b", null ],
    [ "approx", "coeff_8c.html#a4b446d15957e421cf5a909737a139932", null ],
    [ "errexit", "coeff_8c.html#a79e6279cf25598541bdbe66e615cb834", null ],
    [ "linear", "coeff_8c.html#a05930e1a37b4ce996f68ad3d669b7317", null ],
    [ "main", "coeff_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "mult", "coeff_8c.html#ac37ac3310a982739fc0e3110c3aee770", null ],
    [ "orthonormal", "coeff_8c.html#af24f7fce2a1a737df765d965bf83667f", null ],
    [ "readtable", "coeff_8c.html#a61c37be812ad723df1ca7db07ee8d992", null ],
    [ "skalar", "coeff_8c.html#a868cddc7fbb0133ed18115dcc45d9490", null ],
    [ "skalarpoly", "coeff_8c.html#a6fb4bbe454e3326d9aa0fb7be3a80062", null ],
    [ "testresult", "coeff_8c.html#a1349a553525958266d94e548ee03faff", null ],
    [ "value", "coeff_8c.html#a530de41d891986bbb715a1e51a3d8d7f", null ],
    [ "basis", "coeff_8c.html#a8b5e6c0caa4d8ba413e4e7bf2dc38b80", null ],
    [ "n", "coeff_8c.html#a76f11d9a0a47b94f72c2d0e77fb32240", null ],
    [ "x", "coeff_8c.html#a711aad4cbe735871dd9e91ab575c878b", null ],
    [ "y", "coeff_8c.html#a7c3123a306a879fdcbf1b923fcccee07", null ]
];