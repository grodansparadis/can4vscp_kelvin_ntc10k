var searchData=
[
  ['m',['M',['../coeff_8c.html#a52037c938e3c1b126c6277da5ca689d0',1,'coeff.c']]],
  ['max_5flength',['MAX_LENGTH',['../coeff_8c.html#a7a9a231e30b47bc0345749c8bd1e5077',1,'coeff.c']]]
];
