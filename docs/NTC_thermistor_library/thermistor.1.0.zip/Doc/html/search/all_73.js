var searchData=
[
  ['skalar',['skalar',['../coeff_8c.html#a868cddc7fbb0133ed18115dcc45d9490',1,'coeff.c']]],
  ['skalarpoly',['skalarpoly',['../coeff_8c.html#a6fb4bbe454e3326d9aa0fb7be3a80062',1,'coeff.c']]]
];
