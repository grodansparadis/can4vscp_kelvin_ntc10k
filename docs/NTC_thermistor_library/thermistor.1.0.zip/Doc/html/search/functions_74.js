var searchData=
[
  ['testresult',['testresult',['../coeff_8c.html#a1349a553525958266d94e548ee03faff',1,'coeff.c']]],
  ['ttor',['ttor',['../ttor_8c.html#a3e39aa7dba09044c6a29d16959475dfa',1,'ttor.c']]]
];
