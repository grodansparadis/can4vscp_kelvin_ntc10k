var searchData=
[
  ['approx',['approx',['../coeff_8c.html#a4b446d15957e421cf5a909737a139932',1,'coeff.c']]]
];
