var searchData=
[
  ['polynom',['polynom',['../coeff_8c.html#a1a34e732cfb563b8f4e80ed59065c31b',1,'coeff.c']]]
];
