var searchData=
[
  ['x',['x',['../coeff_8c.html#a711aad4cbe735871dd9e91ab575c878b',1,'coeff.c']]]
];
