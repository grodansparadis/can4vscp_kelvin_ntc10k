var searchData=
[
  ['y',['y',['../coeff_8c.html#a7c3123a306a879fdcbf1b923fcccee07',1,'coeff.c']]]
];
