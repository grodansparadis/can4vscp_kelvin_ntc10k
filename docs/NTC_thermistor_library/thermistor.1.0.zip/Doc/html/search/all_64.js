var searchData=
[
  ['debug',['DEBUG',['../coeff_8c.html#ad72dbcf6d0153db1b8d8a58001feed83',1,'coeff.c']]]
];
