var searchData=
[
  ['orthonormal',['orthonormal',['../coeff_8c.html#af24f7fce2a1a737df765d965bf83667f',1,'coeff.c']]]
];
