var searchData=
[
  ['poly',['poly',['../rtot_8c.html#aba0a8b3ba352fad4c0569a5f02316692',1,'rtot.c']]],
  ['polynom',['polynom',['../coeff_8c.html#a1a34e732cfb563b8f4e80ed59065c31b',1,'coeff.c']]]
];
