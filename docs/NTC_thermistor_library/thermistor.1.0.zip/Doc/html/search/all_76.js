var searchData=
[
  ['value',['value',['../coeff_8c.html#a530de41d891986bbb715a1e51a3d8d7f',1,'coeff.c']]]
];
