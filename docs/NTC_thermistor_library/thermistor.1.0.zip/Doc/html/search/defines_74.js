var searchData=
[
  ['tabs',['TABS',['../coeff_8c.html#af3d79ba52f2d41597f8f314c02c86026',1,'TABS():&#160;coeff.c'],['../rtot_8c.html#af3d79ba52f2d41597f8f314c02c86026',1,'TABS():&#160;rtot.c'],['../ttor_8c.html#af3d79ba52f2d41597f8f314c02c86026',1,'TABS():&#160;ttor.c']]]
];
