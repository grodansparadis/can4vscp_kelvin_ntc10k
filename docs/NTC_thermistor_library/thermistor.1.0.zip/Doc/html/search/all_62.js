var searchData=
[
  ['basis',['basis',['../coeff_8c.html#a8b5e6c0caa4d8ba413e4e7bf2dc38b80',1,'coeff.c']]]
];
