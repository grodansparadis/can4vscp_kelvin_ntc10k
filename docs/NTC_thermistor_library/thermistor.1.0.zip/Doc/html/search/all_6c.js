var searchData=
[
  ['linear',['linear',['../coeff_8c.html#a05930e1a37b4ce996f68ad3d669b7317',1,'coeff.c']]]
];
